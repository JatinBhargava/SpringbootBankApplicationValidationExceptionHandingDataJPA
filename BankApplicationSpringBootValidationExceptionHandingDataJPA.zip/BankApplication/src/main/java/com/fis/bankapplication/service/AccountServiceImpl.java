package com.fis.bankapplication.service;

import java.util.List;


import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.AccountDao;
import com.fis.bankapplication.model.Account;

@Service
@Transactional
public class AccountServiceImpl implements AccountService{

	@Autowired
	private AccountDao accountDAO;
	
	@Override
	public String addAccount(Account account) {
			accountDAO.save(account);
			return "Account added to the database";
	}

	@Override
	public Optional<Account> getAccountByAccountId(int accountId) {
			Optional<Account> readAccount = accountDAO.findById(accountId);
			return readAccount;
	}

	@Override
	public String updateAccount(int accountId, double amount) {
//		 Optional<Account> optionalAccount = accountDAO.findById(accountId);
//		 if(optionalAccount.isPresent()) {
//			 Account account = optionalAccount.get();
//			 account.setBalance(amount);
//			 accountDAO.save(account);
//		 }
//		 return "Yeah it's Done";
		accountDAO.updateAccount(accountId, amount);
		return "It's updated";
	}
	
	public String deleteAccount(int accountId) {
		accountDAO.deleteById(accountId);
		return "Account id deleted: " + accountId;
	}

	@Override
	public List<Account> getAllAccountsByBalanceRange(double minBal, double maxBal) {
		return accountDAO.getAllAccountsByBalanceRange(minBal,maxBal);
	}
	
	@Override
	public List<Account> getAllAccounts(){
		return accountDAO.findAll();
	}

}
