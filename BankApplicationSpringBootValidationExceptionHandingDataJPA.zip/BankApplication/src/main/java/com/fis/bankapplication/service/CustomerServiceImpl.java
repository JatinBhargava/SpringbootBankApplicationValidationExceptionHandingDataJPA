package com.fis.bankapplication.service;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.CustomerDao;
import com.fis.bankapplication.exception.CustomerNotFoundException;
import com.fis.bankapplication.exception.EmptyField;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.CustomerService;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerDao customerDAO;
	
	@Override
	public String addUser(Customer customer){
			customerDAO.save(customer);
			return "Customer added to the database";
	}

//	@Override
//	public String updateUser(int customerId,String name,String address) throws CustomerNotFoundException {
//		return customerDAO.updateUser(customerId, name, address);
//	}

	@Override
	public String deleteUser(int customerId) throws CustomerNotFoundException{
			customerDAO.deleteById(customerId);
			return "Customer delete with id:" + customerId;
	}

	@Override
	public Optional<Customer> getUser(int customerId) throws CustomerNotFoundException{
		Optional<Customer> readCustomer = customerDAO.findById(customerId);
		return readCustomer;
	}

	@Override
	public List<Customer> getAllCustomer() {
		return customerDAO.findAll();
	}

}
