package com.fis.bankapplication.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.exception.CustomerNotFoundException;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.CustomerService;

/*
 * Routes:
 * /customers
 * /customers/updateCustomer/{custId}
 * /customers/deleteCustomer/{custId}
 * /customers/getCustomer/{custId}
 * /customers/getAllCustomers
 */

@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	@PostMapping
	public String addCustomer(@RequestBody Customer customer) {
			customerService.addUser(customer);
			return "Customer added to the the Database";
	}
//
//	@PutMapping("updateCustomer/{custId}")
//	public String updateCustomer(
//			@PathVariable("custId") int custId,
//			@RequestParam String name,
//			@RequestParam String address
//			)throws CustomerNotFoundException {
//		String updatedCustomer = customerService.updateUser(custId, name,address);
//		
//		return "Update Customer Done";
//	}
//
	@DeleteMapping("/deleteCustomer/{custId}")
	public String deleteCustomer(@PathVariable("custId") int customerId) throws CustomerNotFoundException{
		customerService.deleteUser(customerId);
		return "Deleted User";
	}
//	
	@GetMapping("/getCustomer/{custId}")
	public Optional<Customer> getCustomer(@PathVariable("custId") int customerId) throws CustomerNotFoundException{
		return customerService.getUser(customerId);
	}
	
	@GetMapping("/getAllCustomers")
	public List<Customer> getCustomers(){
		return customerService.getAllCustomer();
	}
}
